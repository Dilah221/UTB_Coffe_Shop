<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\User;

class ExampleTest extends TestCase
{
    use RefreshDatabase;

    public function test_login()
    {
        $user = User::factory()->create([
            'email' => 'coba1@gmail.com',
            'password' => bcrypt('password'),
        ]);
        $response = $this->post('/login', [
            'email' => 'coba1@gmail.com',
            'password' => 'password',
        ]);

        $response->assertRedirect('/menus');
        $this->assertAuthenticatedAs($user);
    }

    public function test_guest_cannot_access_menus()
    {
        $response = $this->get('/menus');
        $response->assertRedirect('/');
    }
    
    public function test_user_can_logout()
    {
        $user = User::factory()->create();

        $this->actingAs($user);
        $response = $this->post('/logout');

        $response->assertRedirect('/');
        $this->assertGuest();
    }

}
