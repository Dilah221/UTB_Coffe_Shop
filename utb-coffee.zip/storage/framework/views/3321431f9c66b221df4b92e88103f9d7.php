

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3>Dashboard Ekspor Menu</h3>
        <p>Silakan ekspor data menu:</p>
        <a href="<?php echo e(route('menus.index')); ?>" class="btn btn-secondary mb-2">←</a>

        <a href="<?php echo e(route('menus.export.excel')); ?>" class="btn btn-success mb-2">Ekspor ke Excel</a>
        <a href="<?php echo e(route('menus.export.pdf')); ?>" class="btn btn-danger mb-2">Ekspor ke PDF</a>

        <hr>

        <h5>Data Menu Saat Ini:</h5>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nama Menu</th>
                    <th>Deskripsi</th>
                    <th>Harga</th>
                    <th>URL Gambar</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($menu->name); ?></td>
                        <td><?php echo e($menu->description); ?></td>
                        <td>Rp <?php echo e(number_format($menu->price, 0, ',', '.')); ?></td>
                        <td>
                            <?php if($menu->image_url): ?>
                                <a href="<?php echo e($menu->image_url); ?>" target="_blank">Lihat Gambar</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">Belum ada data menu.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Kuliah\Semester 6\Pemograman Web 2\utb-coffee\resources\views/dashboard.blade.php ENDPATH**/ ?>