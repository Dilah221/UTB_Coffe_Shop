

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Daftar Menu UTB Coffee</h2>
    <div class="text-end">
        <a href="<?php echo e(route('menus.create')); ?>" class="btn btn-success">+ Tambah Menu</a>
    </div>

    <div class="row">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100 shadow-sm">
                    <img src="<?php echo e($menu->image_url ?? 'https://via.placeholder.com/300x200.png?text=Menu+Image'); ?>" 
                         class="card-img-top" alt="Menu Image">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?php echo e($menu->name); ?></h5>
                        <p class="card-text"><?php echo e($menu->description); ?></p>
                        <div class="mt-auto">
                            <p class="fw-bold">Rp <?php echo e(number_format($menu->price, 0, ',', '.')); ?></p>
                            <a href="<?php echo e(route('menus.edit', $menu->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('menus.destroy', $menu->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus menu ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Kuliah\Semester 6\Pemograman Web 2\utb-coffee\resources\views/menus/index.blade.php ENDPATH**/ ?>